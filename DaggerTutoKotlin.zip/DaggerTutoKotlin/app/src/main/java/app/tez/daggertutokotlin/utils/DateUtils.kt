package app.tez.daggertutokotlin.utils

import java.util.*
import javax.inject.Inject

/**
 * Created by Terence Zafindratafa on 31/10/2018
 */
class DateUtils {
    fun getCurrentDate(): Date = Date()
}